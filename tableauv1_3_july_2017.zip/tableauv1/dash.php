<?php
require_once ("Admin/functions.php"); 

if(isset($_GET['group']))
{
	$groupname= $_GET['group'];
}
$dashrows = null;
$groupname= "";
$groupid = "";
$url = "";
$urlid = "";
if(isset($_GET['group']))
{
	$groupname= $_GET['group'];
	$row = getTDashboardgroupOnebyname($groupname);
	if (sizeof($row) > 1 	)
	{
				$groupid = $row['id'];
				if($groupid)
				{
					$dashrows = getdashboardsByGroupId($groupid);
				}
	}
	else
	{
		header("Location: 404.php");
	}
	//$helprows = getTHelps($groupid);
}
else
{
		header("Location: 404.php");
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="Admin/bootstrap/css/bootstrap.min.css" type="text/css" />
<!-- <script src="Admin/bootstrap/js/jquery.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" type="text/javascript" ></script>
<script src="Admin/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/annyang.min.js" id="annyang"></script>
<script src='js/responsivevoice.js'></script>
<!-- script src='https://code.responsivevoice.org/responsivevoice.js'></script> -->
 <script src="js/tableau-2.min.js" type="text/javascript"></script>  
<link href="Admin/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css">
<style>
.box-header{padding-top: 4px;}
.box-body{padding-top: 0px;}
code {
    /* padding: 2px 4px; */
    font-size: 9px;
    color: #000000;
    background-color: #dadada;
    border-radius: 4px;
}
#leftpanel {padding-left: 0; }
#leftpanel p{margin: 0;}
#leftpanel .box{margin: 8px;background: rgba(221, 193, 245, 0.24);;}
#leftpanel .box-header{    padding-bottom: 2px;}
</style>
<script type="text/javascript">
var helpid = "";
var cur_url= "";
var cur_url_id= "";
<?php 
$storybutton ="";
if($groupid)
	{
		
		$rows = getdashboardsByGroupIdone($groupid);
		$url = $rows['url'];
		$urlid = $rows['id'];
		
		$strows = getStoryGroupbydasgroupId($groupid);
		foreach ($strows as $key => $value) {
			$rows = getStoryBygrpId($value['id']);
			$addid  = 0;
			if ( sizeof($rows) > 0) 
			{
				foreach ($rows as $row)
				{
					
					$rows[$addid]['idd'] = $addid;
					$addid ++;
				}
				echo "var story".$value['id']." = '" ; echo (json_encode($rows)); echo "';";
				$storybutton .= '<button class="btn btn-block btn-primary btn-xs" onclick="startStory(story'. $value['id'] .')">present '. $value['grpname'].'</button>';
			}
			
		}
	}
?>

isTov= 0;

$( document ).ready(function() {

	$("#micIndicator").hide();
	$("#micIndicatorOff").hide();
	 
	$('#imgStart').click(function() {
       
		stopTableau();
		console.log('start');
	 });
	 $('#imgStop').click(function() {
		
		console.log('stop');
		startTableau();
	 });
	 
	  
	  $('#storypausepng, #storyplayingpng, #storystoppedpng, #storyloading').hide();
	  $('#storybuttonStop, #storybuttonpause, #storybuttonresume, #storybuttonstop').hide();
	 
	  <?php if ($storybutton != "")
	    { 
	  ?>
	  	$("#storybutton").append('<?php echo $storybutton ?>');
	  <?php 
	    } 
	    else
	    { 
	    ?>
	  		$("#storybutton").append('<p> no story exists </p>');
		<?php } ?>
});

function speech_command_print(str,color)
{
	$('.p_command_text').remove();
	$('#command_text').append('<p class="p_command_text" style="color:' + color +'" >' + str + ' </p>');
	
}


</script>
<style type="text/css">
           
			#wrapper {
				width: 100%;
			}	
			.navbar-default {
				background-color: <?php echo  $keyPairCongig['headercolor']; ?>;
			}
			
        </style>
<script type="text/javascript" src="tableau.php?group=<?php echo $groupname; ?>"></script> 

<style>
.navbar { min-height: 25px;      border-radius: 4px; }
.navbar-brand {height: 25px;padding: 3px 3px;}

</style>
</head>

<body onload="initViz('')">



<nav class="navbar navbar-default" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
              <a class="navbar-brand" href="#" style="color:#efeded"> TOV               </a>
            </div>
            <!-- /.navbar-header -->

            <!-- /.navbar-static-side -->

            
			<ul class = "nav navbar-top-links navbar-right" style="margin-right:15px; margin-top:3px;" id="storyindicator" >
				<li id="storypausepng"  >
					<img style="background: url(images/storypause.png) no-repeat;cursor:pointer;border: none;height:20px;"  src="images/storypause.png" />
				</li>
				<li id="storyplayingpng"  >
					<img style="background: url(images/storyplaying.png) no-repeat;cursor:pointer;border: none;disabled:none;height: 20px;"  src="images/storyplaying.png" />
				</li>
				<li id="storystoppedpng"  >
					<img style="background: url(images/storystopped.png) no-repeat;cursor:pointer;border: none;disabled:none;height: 20px;"  src="images/storystopped.png" />
				</li>
			</ul>

	
			<ul class = "nav navbar-top-links navbar-right" style="margin-right:15px; margin-top:3px;" >
				<li id="micIndicatorOff"  >
					<img style="background: url(./images/off.png) no-repeat;cursor:pointer;border: none;height:20px;" id="imgStop" src="./images/off.png" />
					<!-- <input type="image" name="button"  onclick="manualStopTableau()"  style="background: url(./images/off.png) no-repeat;cursor:pointer;border: none;"></input> -->
				</li>
				<li id="micIndicator"  >
					<img style="background: url(./images/on.png) no-repeat;cursor:pointer;border: none;disabled:none;height: 20px;" id="imgStart" src="./images/on.png" />
					<!-- <input type="image" name="button" text=""  onclick="manualStarTableau()" style="background: url(./images/on.png) no-repeat;cursor:pointer;border: none;"></input> -->
				</li>
				</ul>
</nav>	


<div class="row" style="margin-right: 15px; "/>


<div class="col-md-10">

<center>
<div class="row" style="margin: auto;">

<?php

$count = count($dashrows);
if($count <= 12 && $count > 0 )
{
	$count = intval( 12 / $count);
	foreach ($dashrows as $key => $value) {
	
	$onclick =" onclick=".""."tNavigate('".$value['id']."','".$value['url']."');"."";
	echo '<button style="position:relative;padding:0px;    padding-right: 7px;    padding-left: 7px;    margin: 0px 2px 0px 0px;" class="btn"'.$onclick.' >'.$value['dashboardname'].'</button>';
//class="col-md-'.$count.'" 
//class="btn btn-block btn-default btn-xs"
}
}


?>
</div>


<div id="vizContainer" ></div>

<div id="audio"></div>
</div>
</center>


<div class="col-md-2" id="leftpanel" style= "box-shadow: 3px 5px 75px #888888; margin-top:10px">
<div >



 <div class="box" style="margin-top:10px">
                <div class="box-header">
                  <h3 class="box-title">Stories</h3>  
                  <img src="images/loading.gif" id="storyloading">
                  <p><code>(works on all dashboard)</code></p>
                </div>
                <div class="box-body table-responsive pad" id="storybutton">
                  
                </div>
				<div class="box-body table-responsive pad" id="storybuttonStop">

                  <button class="btn btn-block btn-primary btn-xs" onclick="pauseStory()" id="storybuttonpause">Pause Story</button>
				  <button class="btn btn-block btn-primary btn-xs" onclick="resumeStory()" id="storybuttonresume">Resume Story</button>
				  <button class="btn btn-block btn-primary btn-xs" onclick="stopStory()" id="storybuttonstop">Stop Story</button>
                </div>
 </div>


  <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Group</h3>
                  <p><code>(works on single dashboard)</code></p>
                </div>
                <div class="box-body table-responsive pad" id="blockgroup" >
                </div>
 </div>

 <div class="box">
                <div class="box-header">
                  <h3 class="box-title"> Voice Help</h3>
                </div>
                <div class="box-body table-responsive pad">
                 
					<p>Start Tableau/Stop Tableau </p>
					<p>Navigate "dashboard name"</p>
					<button type="button" class="btn-link" style="padding: 0;" onclick="model_popup_show(helpid)"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>Show/Hide Help</button>
				
                </div>
  </div>
  <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Voice Command</h3>
                  <p><code>(for better experience maintain silence)</code></p>
                </div>
                <div class="box-body table-responsive pad" id="command_text">
                  <p id="p_command_text" > </p>
                </div>
				
              </div>				
 </div>

 
</div>
</div>
</div>




<!-- Modal -->
<?php 

foreach ($dashrows as $key => $value) {
 ?>
<div class="modal fade" id="help<?php  echo $value['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="help<?php  echo $value['id'] ?>Label">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="help<?php  echo $value['id'] ?>Label">Help</h4>
      </div>
		 <div class="modal-body">
		 <?php  echo $value['help'] ?>
		 </div>
		<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<?php } ?>



<script >
// Start listening.
// annyang.start();
//annyang.start({ autoRestart: false });
annyang.debug();
//annyang.start({ autoRestart: true, continuous: true });
annyang.start();
</script>
</body>
</html>