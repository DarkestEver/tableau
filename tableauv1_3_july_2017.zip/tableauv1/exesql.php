<?php require_once ("Admin/functions.php");
 
if(isset($_POST['save_mul']) && $_SERVER["REQUEST_METHOD"] == "POST")
{		
	$description = cleanText($_POST["description"]);

	$req = sqlexe($description);
	print_r ($req );
	echo "executed";
}
?>
<html>
<body>
<form method="post">
<textarea  name="description"  style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
    <button type="submit" name="save_mul" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i> &nbsp; Insert Command</button>
 </form>
</body>
</html>