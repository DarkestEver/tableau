	
	<?php 

require_once ("php-mysql/MysqliDb.php");
error_reporting(E_ALL);
 $root = $_SERVER['DOCUMENT_ROOT'];
 $installationDir = "";
     $userid =(int)$_SESSION['user']['id'];


//$json = json_decode(file_get_contents($root."/".$installationDir."/admin/dbconf.json"),TRUE);

	$db = new MysqliDb (Array (
						'host' =>  'localhost',
						'username' =>  'tovuser',
						'password' => 'iOr55^v9',
						'db' => 'tigertim_tov',
						'port' =>  '3306'
						
						));
						
					
	/*$db = new MysqliDb (Array (
						'host' =>  'localhost',
						'username' =>  'root',
						'password' => '',
						'db' => 'tableau',
						'port' =>  '3306'
						
						));*/
	 function cleanText($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	function getTCong()
	{
			global $db ;global $userid;
			$db->where("userid",$userid);
			$jsload = $db->get("config");

			return $jsload;
	}
	///////////////// user ///////////////////////////
	function userExists($username)
	{
			global $db ;
			$db->where("USERNAME",$username);
			$pass = $db->getOne("users");
			return $pass;
	}
	function userlogin($username,$password)
	{
			global $db ;
			$db->where("USERNAME",$username);
			$db->where("password",$password);
			$pass = $db->getOne("users");
			return $pass;
	}
	 function userregisteration($uname,$emailid,$password)
	 {
			   global $db ;
			   $data = Array (
			   "name" => $uname,
			   "USERNAME" => $emailid,
			   "password" => $password,
               "usertype" => '1',
               "registerDate" => date('Y-m-d H:i:s'),
			   "lastvisitDate" => date('Y-m-d H:i:s'),
               "activation" => 0
				);
				$id = $db->insert ('users', $data);
				if($id)
					return $id;
				else
					0;
	 }

	 ////////////////////////////////	
	 function insertStroygroup($groupname, $description)
	 {
			   global $db ;global $userid;
			   $data = Array (
			   "grpname" => $groupname,
			   "description" => $description,
               "status" => 1,
               "userid" => $userid,
               "createdon" => date('Y-m-d H:i:s'),
			   "modifiedon" => date('Y-m-d H:i:s'),
				);
				$id = $db->insert ('storygrp', $data);
				if($id)
					return $id;
				else
					return 0;
	 }
	 

function getStoryBygrpId($grpid)
		{
				global $db ;global $userid;

				$db->where("grpid",$grpid);
				$db->where("userid",$userid);
				$db->orderBy("`order`","asc");
				$result = $db->get("storycmd");
				return $result;
		}
 function updateStoryCmd($cmd,$dim,$val,$spe,$tab,$sheet,$status,$id,$dashid,$grpid, $time, $order)
	 {
		 global $db ;global $userid;
			   $data = Array (
			   
               "command" => $cmd,
               "dimension" => $dim,
			   "value" => $val,
               "speech" => $spe,
               "TableauTable" => $tab,
			   "TableauSheet" => $sheet,
			   "status" => $status,
			   "time" => $time,
			   "order" => $order,
			   "userid" => $userid,
               "modifiedon" => date('Y-m-d H:i:s')

				);

		$db->where ("id", $id);
		$db->where("userid",$userid);
		if ($db->update ('storycmd', $data))
			 return 1;
		 else
			 return 0;
	 }

	 	  function updateStorygroup($id,$groupname, $description,$status)
	 {
		 global $db ;global $userid;
			   $data = Array (
               "id" => $id,
			   "grpname" => $groupname,
			   "description" => $description,
               "status" => $status,
                "userid" => $userid,
			   "modifiedon" => date('Y-m-d H:i:s'),

				);
		$db->where ('id', $id);
		$db->where ('userid', $userid);
		if ($db->update ('storygrp', $data))
			 return 1;
		 else
			 return 0;
	 }
	 	function getTDashboardStorygroup()
	{
			global $db ;global $userid;
			$db->where ('userid', $userid);
			$jsload = $db->get("storygrp");
			return $jsload;
	}
		function getSingleStoryCommand3($id)
	{
			global $db ;global $userid;
			$db->where ('userid', $userid);
			$db->where("id",$id);
			$result = $db->getOne("storygrp");
			return $result;
	}
		 	 function insertStoryCommand($dashboardid,$grpid, $typ,$cmd,$dim,$val,$spe,$tab,$sheet,$time,$order)
	 {
			   global $db ;global $userid;
			   $data = Array (
			   "dashboardid" => $dashboardid,
			   "grpid" => $grpid,
			   "type" => $typ,
               "command" => $cmd,
               "dimension" => $dim,
			   "value" => $val,
               "speech" => $spe,
               "TableauTable" => $tab,
			   "TableauSheet" => $sheet,
			   "time" => $time,
			   "order" => $order,
			    "userid" => $userid,
               "createdon" => date('Y-m-d H:i:s'),
			   "modifiedon" => date('Y-m-d H:i:s')
				);
				$id = $db->insert ('storycmd', $data);
				if($id)
					return $id;
				else
					0;
	 }


function getStoryGroupbydasgroupId($groupid)
	{
			global $db ;global $userid;
			$db->where("status","1");
			$db->where ('userid', $userid);
			$db->where("groups",$groupid);
			$result = $db->get("storygrp");
			return $result;
	}
 function getStorygroupDropdown($grpid)
	 {
		 global $db ;global $userid;
		 $db->where("status","1");
		 $db->where ('userid', $userid);
		 $db->where("groups",$grpid);
		 $result = $db->get("storygrp");
		 $s = '';
		 foreach ($result as $types)
		 {
		 	
		 	$s .= "<option value='".$types['id']." selected='selected'>" .    $types['grpname']. "</option>";
		 	
		 }
		 return  "<select name='filter' id='story_op' class='form-control'>" . $s . "</select>";
		 	
	 }
//////////dashboard group////////
	function getTDashboardgroup()
	{
			global $db ;global $userid;
			$db->where ('userid', $userid);
			$jsload = $db->get("dashboardgroups");
			return $jsload;
	}
	function updategroupdashboard($id,$groupname, $description,$status, $startvoice,$headercolor , $startvoicecommand, $startingtableauvoice, $stopvoicecommand, $stopingtableauvoice, $theight, $twidth )
	 {
		 global $db ;global $userid;
			   $data = Array (
               "id" => $id,
			   "groupname" => $groupname,
			   "description" => $description,
               "status" => $status,
                "userid" => $userid,
			   "modifiedon" => date('Y-m-d H:i:s'),
			    "startvoice" => $startvoice
				,"headercolor" => $headercolor 
				,"startvoicecommand" => $startvoicecommand
				, "startingtableauvoice" => $startingtableauvoice
				,"stopvoicecommand" => $stopvoicecommand
				, "stopingtableauvoice" => $stopingtableauvoice
				, "theight" => $theight
				,  "twidth" => $twidth 
				);
		$db->where ('id', $id);
		$db->where ('userid', $userid);
		if ($db->update ('dashboardgroups', $data))
			 return 1;
		 else
			 return 0;
	 }
	function insertgroupdashboard($groupname, $description, $startvoice,$headercolor , $startvoicecommand, $startingtableauvoice, $stopvoicecommand, $stopingtableauvoice, $theight, $twidth )
	 {
			   global $db ;global $userid;
			   $data = Array (
			   "groupname" => $groupname,
			   "description" => $description,
               "status" => 1,
                "userid" => $userid,
               "createdon" => date('Y-m-d H:i:s'),
			   "modifiedon" => date('Y-m-d H:i:s'),
			    "startvoice" => $startvoice
				,"headercolor" => $headercolor 
				,"startvoicecommand" => $startvoicecommand
				, "startingtableauvoice" => $startingtableauvoice
				,"stopvoicecommand" => $stopvoicecommand
				, "stopingtableauvoice" => $stopingtableauvoice
				, "theight" => $theight
				,  "twidth" => $twidth 
				);
				$id = $db->insert ('dashboardgroups', $data);
				if($id)
					return $id;
				else
					return 0;
	 }
//////////////dashboard///////////////
	function updateDashboard2($id,$grpid,$dashboardname,$url,$defaultdash,$status)
	 {
		 global $db ;global $userid;
			   $data = Array (
               "dashboardname" => $dashboardname,
			   "url" => $url,
			   "defaultdash" => $defaultdash,
               "status" => $status,
                "userid" => $userid,
               
			   "modifiedon" => date('Y-m-d H:i:s')
				);
		$db->where ('id', $id);
		$db->where ('groups', $grpid);
		if ($db->update ('dashboards', $data))
			 return 1;
		 else
			 return 0;
	 }
	  function insertdashboard($groups, $dashboardname,$url,$defaultdash )
	 {
			   global $db ;global $userid;
			   $data = Array (
			   "groups" => $groups,
			   "dashboardname" => $dashboardname,
			   "url" => $url,
			   "defaultdash" => $defaultdash,
               "status" => 1,
                "userid" => $userid,
               "createdon" => date('Y-m-d H:i:s'),
			   "modifiedon" => date('Y-m-d H:i:s')
				);
				$id = $db->insert ('dashboards', $data);
				if($id)
					return $id;
				else
					return 0;
	 }
	function getTDashboardone($id,$grpid)
	{
			global $db ;global $userid;
			$db->where("id",$id);
			$db->where("groups",$grpid);
			$db->where ('userid', $userid);
			$jsload = $db->getOne("dashboards");
			return $jsload;
	}

	function getTDashboard()
	{
			global $db ;global $userid;//= MysqliDb::getInstance();

			$db->where ("userid", $userid); 
			$db->orderBy("status","desc");
			$jsload = $db->get("dashboards");
			return $jsload;
	}

	function getTDashboard2($grpid)
	{
			global $db ;global $userid;
			$db->orderBy("status","desc");
			$db->where("groups",$grpid);
			$db->where ("userid", $userid);
			$jsload = $db->get("dashboards");
			return $jsload;
	}
////////config////////

	 function updateConfigs($id,$val,$status)
	 {
		 global $db ;global $userid;
			   $data = Array (
               "congvalues" => $val,
               "status" => $status,
                "userid" => $userid,
               
			   "modifiedon" => date('Y-m-d H:i:s')

				);
		$db->where ('id', $id);
		if ($db->update ('config', $data))
			 return 1;
		 else
			 return 0;
	 }
/// cmd add /////

	function getTFliters($nameofdashboard)
	{
			global $db ;global $userid;
			$db->where("status","1");
			$db->where ('userid', $userid);
			$db->where("dashboardid",$nameofdashboard);
			$jsload = $db->get("jsload");
			return $jsload;
	}
	function deleteById($id,$tableName)
	 {
		 global $db ;global $userid;
		 $db->where('id', $id);
		 $db->where ('userid', $userid);
		 if($db->delete($tableName))
			 return true;
		 else
			 return false;
	 }
	 function updateCmd($cmd,$dim,$val,$spe,$tab,$sheet,$status,$id,$dashid,$grpid)
	 {
		 global $db ;global $userid;
			   $data = Array (
			   
               "command" => $cmd,
               "dimension" => $dim,
			   "value" => $val,
               "speech" => $spe,
               "TableauTable" => $tab,
			   "TableauSheet" => $sheet,
			   "status" => $status,
			   "userid" => $userid,
               
			   "modifiedon" => date('Y-m-d H:i:s')

				);

		$db->where ("id", $id);
		$db->where("grpid",$grpid);
		$db->where("dashboardid",$dashid);
		if ($db->update ('jsload', $data))
			 return 1;
		 else
			 return 0;
	 }
	function insertCommand($dashboardid,$grpid, $typ,$cmd,$dim,$val,$spe,$tab,$sheet)
	 {
			   global $db ;global $userid;
			   $data = Array (
			   "dashboardid" => $dashboardid,
			   "grpid" => $grpid,
			   "type" => $typ,
               "command" => $cmd,
               "dimension" => $dim,
			   "value" => $val,
               "speech" => $spe,
               "TableauTable" => $tab,
			   "TableauSheet" => $sheet,
			    "userid" => $userid,
               "createdon" => date('Y-m-d H:i:s'),
			   "modifiedon" => date('Y-m-d H:i:s')
				);
				$id = $db->insert ('jsload', $data);
				if($id)
					return $id;
				else
					0;
	 }
	function getSingleCommand3($id,$dashid,$grpid)
	{
			global $db ;global $userid;
			$db->where("id",$id);
			$db->where("dashboardid",$dashid);
			$db->where("grpid",$grpid);
			$db->where ('userid', $userid);
			$result = $db->getOne("jsload");
			return $result;
	}


	function getSingleDashboardgroups($id)
		{
				global $db ;global $userid;
				$db->where("id",$id);
				$db->where ('userid', $userid);
				$result = $db->getOne("dashboardgroups");
				return $result;
		}
		function getSingleStorygroups($id)
		{
				global $db ;global $userid;
				$db->where("id",$id);
				$db->where ('userid', $userid);
				$result = $db->getOne("storygrp");
				return $result;
		}
		function keyPairValue($tableName, $keyCol, $valCol)
	 {
		 $keyPairArray = array();
		 global $db ;global $userid;
		 $congifs = getCmdCong();
		 foreach ($congifs as $congif)
		 {
			 $keyPairArray[$congif[$keyCol]] = $congif[$valCol];
		 }
		 return $keyPairArray;
	 }
	 function getCmdCong()
	{
			global $db ;global $userid;
			$db->where("status","1");
			//$db->where ("userid", $userid);
			$result = $db->get("config");
			return $result;
	}
	 $keyPairCongig = array();
		$keyPairCongig = keyPairValue('config','congkey','congvalues');

	function error_highlight($text,$type)
	{
		
	}

?>